# uj-bit-gang.github.io

# Website with updates daily for Business IT students @University of Johannesburg

# Website is updated many times a day.

# The mail.php file is hosted on my personal server as github does no run .php files and only accepts @student.uj.ac.za emais

# Please do no sabotage the website, rather contact us if there is something you want removed
